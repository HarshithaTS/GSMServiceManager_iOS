//
//  GQPQueueProcessor.m
//  GenericQueueProcessor
//
//  Created by Riyas Hassan on 30/10/14.
//  Copyright (c) 2014 GSS Software. All rights reserved.
//

#import "GQPQueueProcessor.h"

#import "Reachability.h"

#import "QueuedProcess.h"

#import "Constants.h"

#import "ErrorLog.h"

#import "GSPKeychainStoreManager.h"

@implementation GQPQueueProcessor

@synthesize fourDaysTimer,fourHrsTimer,oneDayTimer,oneHrTimer,oneMintTimer,sevenDaysTimer,tenMintsTimer;

@synthesize backgroundTask;

+ (id)sharedInstance
{
    static GQPQueueProcessor *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    
    return sharedInstance;
}


- (void) getDataFormKeyChainAndProcess
{
    [self saveDataToQueueDBFromKeyChain];
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    
    if ([reachability isReachable])
    {
        NSLog(@"Reachable");
        [self getDataFromDBAndSendToSAPServer];
        
        [self start7Timers];
    }
    else
    {
        NSLog(@"Unreachable");
        //Do Nothing
    }
 
}

- (void) start7Timers
{
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    
    [request setEntity:[NSEntityDescription entityForName:@"QueuedProcess" inManagedObjectContext:context]];
    
    NSError *error                  = nil;
    
   
    NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",1];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountOneArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountOneArray.count > 0)
    {
        oneMintTimer    = [NSTimer timerWithTimeInterval:60.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"1 Mint" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:oneMintTimer forMode:NSRunLoopCommonModes];
    }
    
    predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",2];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountTwoArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountTwoArray.count > 0)
    {
        tenMintsTimer   = [NSTimer timerWithTimeInterval:600.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"10 Mints" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:tenMintsTimer forMode:NSRunLoopCommonModes];
    }
    
    predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",3];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountThreeArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountThreeArray.count > 0)
    {
        oneHrTimer      = [NSTimer timerWithTimeInterval:3600.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"1 Hour" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:oneHrTimer forMode:NSRunLoopCommonModes];
    }
    
    predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",4];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountFourArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountFourArray.count > 0)
    {
        fourHrsTimer    = [NSTimer timerWithTimeInterval:14400.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"4 Hours" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:fourHrsTimer forMode:NSRunLoopCommonModes];
    }
    
    predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",5];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountFiveArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountFiveArray.count > 0)
    {
        oneDayTimer     = [NSTimer timerWithTimeInterval:86400.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"1 Day" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:oneDayTimer forMode:NSRunLoopCommonModes];
    }
    
    predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",6];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountSixArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountSixArray.count > 0)
    {
        fourDaysTimer   = [NSTimer timerWithTimeInterval:345600.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"4 Days" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:fourDaysTimer forMode:NSRunLoopCommonModes];
    }
    
    predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",7];
    [request setPredicate:predicate];
    
    NSMutableArray * processCountSevenArray      = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    if (processCountSevenArray.count > 0)
    {
        sevenDaysTimer  = [NSTimer timerWithTimeInterval:604800.0 target:self selector:@selector(processDataInQueueTableToSapWebServer:) userInfo:@"7 Days" repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:sevenDaysTimer forMode:NSRunLoopCommonModes];
    }
    
}


- (void)processDataInQueueTableToSapWebServer:(NSTimer*)timer
{
    NSString * timerInfo = timer.userInfo;
    
    NSLog(@"Timer info is : %@", timerInfo);
    
    
    NSMutableArray *tempArray = [NSMutableArray new];
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    
    [request setEntity:[NSEntityDescription entityForName:@"QueuedProcess" inManagedObjectContext:context]];
    
     NSError *error                  = nil;
    
    
    if ([timerInfo isEqualToString:@"1 Mint"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",1];
        [request setPredicate:predicate];
    }
    else if ([timerInfo isEqualToString:@"10 Mints"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",2];
        [request setPredicate:predicate];
    }
    
    else if ([timerInfo isEqualToString:@"1 Hour"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",3];
        [request setPredicate:predicate];
    }
    else if ([timerInfo isEqualToString:@"4 Hours"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",4];
        [request setPredicate:predicate];
    }
    else if ([timerInfo isEqualToString:@"1 Day"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",5];
        [request setPredicate:predicate];
    }
    else if ([timerInfo isEqualToString:@"4 Days"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",6];
        [request setPredicate:predicate];
    }
    else if ([timerInfo isEqualToString:@"7 Days"])
    {
        NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"processCount = %d",7];
        [request setPredicate:predicate];
    }
 
    
   
    tempArray              = (NSMutableArray*)[context executeFetchRequest:request error:&error];

    for (int i = 0; i < tempArray.count ; i++)
    {
        [self updateProcessStartedDetailsInDBForObject:[tempArray objectAtIndex:i]];
        [self initializeWebServiceCallForObject:[tempArray objectAtIndex:i]];
    }

}


- (void) saveDataToQueueDBFromKeyChain
{
    
    NSMutableArray * arrayOfTasksFromKeyChain = [GSPKeychainStoreManager arrayFromKeychain];
    
    [self saveInDB:arrayOfTasksFromKeyChain];
    
}

- (void)getDataFromDBAndSendToSAPServer
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"QueuedProcess" inManagedObjectContext:context]];
    
    NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"status != %@ OR status = NULL",@"Completed" ];// OR status != %@,@"Processing"];
    [request setPredicate:predicate];

    
    NSError *error                  = nil;
    fetchedResultArray              = (NSMutableArray*)[context executeFetchRequest:request error:&error];
    
    processItemNumber = 0;
    [self processWebServiceRequestToSap];

}


- (void)processWebServiceRequestToSap
{
    if (processItemNumber < fetchedResultArray.count  )
    {
        [self updateProcessStartedDetailsInDBForObject:[fetchedResultArray objectAtIndex:processItemNumber]];
        [self initializeWebServiceCallForObject:[fetchedResultArray objectAtIndex:processItemNumber]];
        processItemNumber++;
    }
    else if (fetchedResultArray.count <= 0 || fetchedResultArray == nil)
    {
        //Do Nothing. Stop Processing
    }
    else
    {
        processItemNumber   = 0;
        fetchedResultArray  = nil;
        //[self getDataFromDBAndSendToSAPServer];
    }
  
}


- (void)initializeWebServiceCallForObject:(QueuedProcess*)object
{
    GssMobileConsoleiOS *objServiceMngtCls      = [[GssMobileConsoleiOS alloc] init];
    
    objServiceMngtCls.ApplicationName           = [object valueForKey:@"appName"];
    objServiceMngtCls.ApplicationVersion        = [object valueForKey:@"subApplicationVersion"];
    objServiceMngtCls.ApplicationEventAPI       = [object valueForKey:@"apiName"];
    
    NSString *tempStr                           = [object valueForKey:@"inputDataArrayString"];
    objServiceMngtCls.InputDataArray            = [self createMutableArray:[tempStr componentsSeparatedByString:@","]];
    objServiceMngtCls.Options                   = @"UPDATEDATA";
    objServiceMngtCls.RefernceID                = [object valueForKey:@"referenceID"];
    
    objServiceMngtCls.subApp                    = [object valueForKey:@"subApplication"];
    objServiceMngtCls.objectType                = [object valueForKey:@"objectType"];
    
    
    //objServiceMngtCls.CRMdelegate              = self;
    
    [objServiceMngtCls callSOAPWebMethodWithBlock:^(GQPWebServiceResponse * response)
     {

         
        if (response.responseArray) {
            
             if (response.responseArray.count > 3)
             {
                 NSString * message = [[response.responseArray objectAtIndex:0] objectAtIndex:0];
                 
                 if ([message isEqualToString:@"E"])
                 {
                     //Update Error table
                     NSLog(@"Error for reference id : %@",response.referenceID );
                     
                     [self updateProcessStatusInDBForObjectWithReferenceID:response.referenceID withStatus:@"Error"];
                     [self updateErrorTableForReferenceId:response.referenceID andErrorObject:response.responseArray andErrorMessage:@"Error"];
                     
                 }
                 else  if ([message isEqualToString:@"S"])
                 {
                     // Update sucess status in Db
                     NSLog(@"Sucess for reference id : %@",response.referenceID );
                     [self updateProcessStatusInDBForObjectWithReferenceID:response.referenceID withStatus:@"Completed"];
                 }
             }
         }
         
         else if (response.errorResponseMessage)
         {
             [self updateProcessStatusInDBForObjectWithReferenceID:response.referenceID withStatus:@"Error"];
             
             [self updateErrorTableForReferenceId:response.referenceID andErrorObject:response.responseArray andErrorMessage:response.errorResponseMessage];
         }
         
         
         [self processWebServiceRequestToSap];
     }];
}


- (NSMutableArray *)createMutableArray:(NSArray *)array
{
    return [array mutableCopy];
}


#pragma mark coredata methods

- (NSManagedObjectContext *)managedObjectContext {
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}

- (void)saveInDB:(NSMutableArray*)objectArray
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    // Create a new managed object
    
    
    for (NSDictionary * taskDic in objectArray)
    {
        NSLog(@"item is %@", [taskDic objectForKey:@"referenceid"] );
    
        [self checkAndDeleteRecordsAlreadyExistsDB:@"QueuedProcess" forRefID:[taskDic objectForKey:@"referenceid"] andApplicationName:[taskDic objectForKey:@"applicationname"]];
        
        NSManagedObject *process = [NSEntityDescription insertNewObjectForEntityForName:@"QueuedProcess" inManagedObjectContext:context];
        
        
        [process setValue:[taskDic objectForKey:@"applicationname"] forKey:@"appName"];
        [process setValue:[taskDic objectForKey:@"referenceid"] forKey:@"referenceID"];
        [process setValue:[taskDic objectForKey:@"packageName"] forKey:@"packageName"];
        [process setValue:[taskDic objectForKey:@"AddedTime"] forKey:@"queueDate"];
        
        [process setValue:[NSNumber numberWithInt:[[taskDic objectForKey:@"attempt"]integerValue]] forKey:@"processCount"];
        [process setValue:[taskDic objectForKey:@"inputdataarraystring"] forKey:@"inputDataArrayString"];
        [process setValue:[taskDic objectForKey:@"objecttype"] forKey:@"objectType"];
        [process setValue:[taskDic objectForKey:@"periority"] forKey:@"periority"];
        [process setValue:[taskDic objectForKey:@"subapplication"] forKey:@"subApplication"];
        [process setValue:[taskDic objectForKey:@"subapplicationversion"] forKey:@"subApplicationVersion"];
        
        [process setValue:[taskDic objectForKey:@"applicationeventapi"] forKey:@"apiName"];
        [process setValue:[taskDic objectForKey:@"ID"] forKey:@"altID"];
        [process setValue:[taskDic objectForKey:@"created"] forKey:@"processStartTime"];
        [process setValue:[taskDic objectForKey:@"deviceid"] forKey:@"deviceID"];
        [process setValue:[taskDic objectForKey:@"endtime"] forKey:@"endTime"];

        
        
        NSError *error = nil;
        // Save the object to persistent store
        if (![context save:&error]) {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }
        else
        {
            NSLog(@"Saved successfully");
        }
        
    }

    [GSPKeychainStoreManager deleteItemsFromKeyChain];
}

- (void)checkAndDeleteRecordsAlreadyExistsDB:(NSString*)entityName forRefID:(NSString*)objectID andApplicationName:(NSString*)appName
{
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:entityName inManagedObjectContext:context]];//@"QueuedProcess"
    
    NSError *error                  = nil;
    NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"referenceID = %@ AND appName = %@", objectID,appName];
    [request setPredicate:predicate];
    NSArray *results                = [context executeFetchRequest:request error:&error];
    
    if (results.count > 0)
    {
        for (NSManagedObject* object in results)
        {
            [context deleteObject:object];
        }
        
        [context save:&error];
    }
    
}

- (void)updateProcessStartedDetailsInDBForObject:(QueuedProcess*)object
{
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"QueuedProcess" inManagedObjectContext:context]];
    
    NSError *error                  = nil;
    NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"referenceID = %@ AND appName = %@", object.referenceID,object.appName];
    [request setPredicate:predicate];
    NSArray *results                = [context executeFetchRequest:request error:&error];
    if (results.count > 0)
    {
        NSManagedObject *coredataObject = [results objectAtIndex:0];
        
        NSNumber *processCount          = [coredataObject valueForKey:@"processCount"];
        
        processCount                    = [NSNumber numberWithInt:[processCount integerValue] + 1 ];
        
        [coredataObject setValue:processCount forKey:@"processCount"];
        [coredataObject setValue:@"Processing" forKey:@"status"];
        [coredataObject setValue:[NSString stringWithFormat:@"%@",[NSDate date]] forKey:@"processStartTime"];
        
        
        if (![context save:&error]) {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }
        else
        {
            NSLog(@"Saved successfully");
        }

    }
    
}


- (void)updateProcessStatusInDBForObjectWithReferenceID:(NSString*)refId withStatus:(NSString*)status
{
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"QueuedProcess" inManagedObjectContext:context]];
    
    NSError *error                  = nil;
    NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"referenceID = %@",refId];
    [request setPredicate:predicate];
    NSArray *results                = [context executeFetchRequest:request error:&error];
    
    if (results.count > 0)
    {
        NSManagedObject *coredataObject = [results objectAtIndex:0];
        
        [coredataObject setValue:status forKey:@"status"];
        [coredataObject setValue:[NSString stringWithFormat:@"%@",[NSDate date]] forKey:@"endTime"];
        
        
        if (![context save:&error]) {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }
        else
        {
            NSLog(@"Saved successfully");
        }
    }
    
    
}

- (void) updateErrorTableForReferenceId:(NSString*)refId andErrorObject:(NSMutableArray*)responseObject andErrorMessage:(NSString*)errorMessage
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"QueuedProcess" inManagedObjectContext:context]];
    
    NSError *error                  = nil;
    NSPredicate *predicate          = [NSPredicate predicateWithFormat:@"referenceID = %@",refId];
    [request setPredicate:predicate];
    NSArray *results                = [context executeFetchRequest:request error:&error];
    
    QueuedProcess *coredataObject   = (QueuedProcess*)[results objectAtIndex:0];
    
    NSNumber *processCount         = [coredataObject valueForKey:@"processCount"];
    
    if ([processCount integerValue] >= 7){
        
        if (responseObject.count > 0) {
            
            NSArray *errResponseArray   = [responseObject objectAtIndex:0];
            
            NSString *errorType         = [errResponseArray objectAtIndex:0];
            errResponseArray            = [responseObject objectAtIndex:3];
            NSString * errorDesc        = [errResponseArray objectAtIndex:0];
            
            [self insertNewErrorRecordInDbWithRefID:refId andCoredatObj:coredataObject errorType:errorType andEroorDesc:errorDesc];
        }
        else
        {
            [self insertNewErrorRecordInDbWithRefID:refId andCoredatObj:coredataObject errorType:errorMessage andEroorDesc:errorMessage];
        }
        
          
    }
    
}


- (void)insertNewErrorRecordInDbWithRefID:(NSString*)refID andCoredatObj:(QueuedProcess*)coreDataObj errorType:(NSString*)errorType andEroorDesc:(NSString*)errorDesc
{
    
     [self checkAndDeleteRecordsAlreadyExistsDB:@"ErrorLog"  forRefID:refID andApplicationName:[coreDataObj valueForKey:@"appName"]];
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSManagedObject *errorLog = [NSEntityDescription insertNewObjectForEntityForName:@"ErrorLog" inManagedObjectContext:context];

    [errorLog setValue:refID forKey:@"referenceID"];
    [errorLog setValue:[coreDataObj valueForKey:@"appName"] forKey:@"appName"];
    [errorLog setValue:[coreDataObj valueForKey:@"apiName"] forKey:@"apiName"];
    [errorLog setValue:errorType forKey:@"errType"];
    [errorLog setValue:errorDesc forKey:@"errDescription"];
    [errorLog setValue:[NSString stringWithFormat:@"%@",[NSDate date]] forKey:@"errDate"];
    [errorLog setValue:@"ERROR" forKey:@"status"];
    
    NSError *error = nil;
    if (![context save:&error])
    {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    else
    {
        NSLog(@"Saved successfully");
    }

}

- (NSMutableArray*) getErrorOccuredItemsFromDB
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *request         = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"ErrorLog" inManagedObjectContext:context]];
    
    NSError *error                  = nil;
    NSArray *results                = [context executeFetchRequest:request error:&error];

    return (NSMutableArray*)results;
}


- (void)saveErrorItemsInKeyChain
{
    
    NSMutableArray * erorrItems = [self getErrorOccuredItemsFromDB];

    [GSPKeychainStoreManager saveErrorItemsInKeychain:erorrItems];
    
 
}




@end
