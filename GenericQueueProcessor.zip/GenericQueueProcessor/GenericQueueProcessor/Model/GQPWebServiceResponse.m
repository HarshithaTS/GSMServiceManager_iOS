//
//  GQPWebServiceResponse.m
//  GenericQueueProcessor
//
//  Created by Riyas Hassan on 05/11/14.
//  Copyright (c) 2014 GSS Software. All rights reserved.
//

#import "GQPWebServiceResponse.h"

@implementation GQPWebServiceResponse

@synthesize referenceID;
@synthesize action;
@synthesize responseMsg;
@synthesize responseArray;
@synthesize errorResponseMessage;
@end
