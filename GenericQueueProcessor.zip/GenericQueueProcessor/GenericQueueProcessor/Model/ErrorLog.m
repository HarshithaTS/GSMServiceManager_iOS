//
//  ErrorLog.m
//  GenericQueueProcessor
//
//  Created by Riyas Hassan on 04/11/14.
//  Copyright (c) 2014 GSS Software. All rights reserved.
//

#import "ErrorLog.h"


@implementation ErrorLog

@dynamic referenceID;
@dynamic appName;
@dynamic apiName;
@dynamic errType;
@dynamic errDescription;
@dynamic errDate;
@dynamic status;

@end
